package com.example.restapi

data class DogApiResponse(val message: String)
